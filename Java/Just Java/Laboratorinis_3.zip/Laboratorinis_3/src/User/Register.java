package User;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Register {
    private static final Map<String, String> users = new HashMap<>();

    public static void registerUser(Scanner scanner) {
        System.out.println("Vartotojo registracija:");
        System.out.print("Įveskite vartotojo vardą: ");
        String username = scanner.next();
        System.out.print("Įveskite slaptažodį: ");
        String password = scanner.next();

        users.put(username, password);

        System.out.println("Registracija sėkminga!");
    }

    public static String login(Scanner scanner) {
        System.out.println("Prisijungimas:");
        System.out.print("Įveskite vartotojo vardą: ");
        String username = scanner.next();
        System.out.print("Įveskite slaptažodį: ");
        String password = scanner.next();

        if (("ugnius".equals(username) && "123".equals(password)) || (users.containsKey(username) && users.get(username).equals(password))) {
            if ("ugnius".equals(username) && "123".equals(password)) {
                return "worker_ugnius";
            } else {
                return username.startsWith("worker") ? "worker" : "user";
            }
        } else {
            System.out.println("Neteisingas vartotojo vardas arba slaptažodis. Bandykite dar kartą.");
            return null;
        }
    }
}
