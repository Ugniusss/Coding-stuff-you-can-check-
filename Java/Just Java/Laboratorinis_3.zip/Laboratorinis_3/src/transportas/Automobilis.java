package transportas;

public class Automobilis {
    private final String marke;
    private final int metai;

    public Automobilis(String marke, int metai) {
        this.marke = marke;
        this.metai = metai;
    }

    public void papildymas() {
        System.out.println("Atnaujinami masinos resursai");
    }
    public final void plovimas() {
        System.out.println("Automobilis nuplautas");
    }
    public String getMarke() {
        return marke;
    }

    public int getMetai() {
        return metai;
    }

    public String toString() {
        return "Automobilis : " + marke + ", " + metai + " m.";
    }
}

