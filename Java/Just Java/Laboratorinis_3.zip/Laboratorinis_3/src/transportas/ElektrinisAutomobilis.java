package transportas;

public class ElektrinisAutomobilis extends Automobilis {
    private final String model;
    private static final String kuroTipas = "Elektra";
    public ElektrinisAutomobilis(String marke, String model, int metai) {
        super(marke, metai);
        this.model = model;
    }

    @Override
    public void papildymas() {
        System.out.println("Kraunama elektros baterija.");
    }

    @Override
    public String toString() {
        return "E : " + getMarke() + ", " + model + ", " + getMetai() + " m., " + kuroTipas;
    }

}
