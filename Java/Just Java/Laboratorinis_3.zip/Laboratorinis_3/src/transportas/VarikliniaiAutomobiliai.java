package transportas;

public class VarikliniaiAutomobiliai extends Automobilis {
    private static final String kuroTipas = "Dyzelis/Benzinas";
    private final String model;

    public VarikliniaiAutomobiliai(String marke, String modelis, int metai) {
        super(marke, metai);
        this.model = modelis;

    }
    public String getModelis(){
        return this.model;
    }
    @Override
    public void papildymas() {
        System.out.println("Pilamas " + kuroTipas);
    }

    @Override
    public String toString() {
        return "V : " + getMarke() + " " + getModelis() + ", " + getMetai() + " m., " + kuroTipas;
    }
}

