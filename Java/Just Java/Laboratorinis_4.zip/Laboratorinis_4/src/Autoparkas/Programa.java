package Autoparkas;

import User.Register;
import transportas.Automobilis;
import transportas.ElektrinisAutomobilis;
import transportas.VarikliniaiAutomobiliai;

import java.util.Scanner;

public class Programa {


    public static void main(String[] args) {
        //CONSOLE
        for (int i = 0; i < 50; ++i) System.out.println();
        //CONSOLE

        AutParkas autoparkas = new AutParkas();
        Scanner scanner = new Scanner(System.in);

        // PRADINES MASINOS
        autoparkas.addAuto(new VarikliniaiAutomobiliai("Toyota", "Camry", 2020));
        autoparkas.addAuto(new VarikliniaiAutomobiliai("Ford", "Mustang", 2019));
        autoparkas.addAuto(new VarikliniaiAutomobiliai("Honda", "Civic", 2022));
        autoparkas.addAuto(new ElektrinisAutomobilis("Tesla", "Model S", 2021));
        autoparkas.addAuto(new ElektrinisAutomobilis("Nissan", "Leaf", 2023));
        // PRADINES MASINOS

        boolean exit = false;

        while (!exit) {
            System.out.println("\nPasirinkite veiksmą:");
            System.out.println("1. Prisiregistruoti");
            System.out.println("2. Prisijungti");
            System.out.println("3. Baigti programą");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1 -> Register.registerUser(scanner);
                case 2 -> {
                    String userType = Register.login(scanner);
                    if (userType != null) {
                        if ("worker_ugnius".equals(userType)) {
                            userType = "worker";
                        }
                        login(scanner, autoparkas, userType);
                    }
                }
                case 3 -> {
                    exit = true;
                    System.out.println("Programa baigta.");
                }
                default -> System.out.println("Neteisingas pasirinkimas. Bandykite dar kartą.");
            }
        }

        scanner.close();
    }

    private static void login(Scanner scanner, AutParkas autoparkas, String userType) {boolean loggedIn = true;
        while (loggedIn) {
            if ("user".equals(userType)) {
                System.out.println("\nPasirinkite veiksmą:");
                System.out.println("1. Nuomuoti automobilį");
                System.out.println("2. Peržiūrėti laisvus automobilius");
                System.out.println("3. Grąžinti automobilį");
                System.out.println("4. Atsijungti");

                int choice = scanner.nextInt();

                switch (choice) {
                    case 1 -> NuomuotiAut(scanner, autoparkas, "user");
                    case 2 -> perziuretLaisvas(autoparkas);
                    case 3 -> Grazinti(autoparkas);
                    case 4 -> {
                        loggedIn = false;
                        System.out.println("Atsijungta.");
                    }
                    default -> System.out.println("Neteisingas pasirinkimas. Bandykite dar kartą.");
                }
            } else if (userType.equals("worker")) {
                System.out.println("\nPasirinkite veiksmą:");
                System.out.println("1. Peržiūrėti laisvus automobilius");
                System.out.println("2. Registruoti naują automobilį");
                System.out.println("3. Peržiūrėti išsinuotus automobilius");
                System.out.println("4. Papildyti automobilio resursus");
                System.out.println("5. Nuplauti automobili");
                System.out.println("6. Atsijungti");

                int choice = scanner.nextInt();

                switch (choice) {
                    case 1 -> perziuretLaisvas(autoparkas);
                    case 2 -> Pridet(scanner, autoparkas);
                    case 3 -> perziuretIsnuomuotas(autoparkas);
                    case 4 -> callPapildymas(scanner, autoparkas);
                    case 5 -> callPlovimas(scanner, autoparkas);
                    case 6 -> {
                        loggedIn = false;
                        System.out.println("Atsijungta.");
                    }
                    default -> System.out.println("Neteisingas pasirinkimas. Bandykite dar kartą.");
                }
            }
        }
    }


    public static void NuomuotiAut(Scanner scanner, AutParkas autoparkas, String username) {
        if (autoparkas.arUserNuomuojasi(username)) {
            System.out.println("Jūs jau esate išsinuomavęs automobilį. Grąžinkite jį prieš nuomodami kitą.");
        } else {
            System.out.println("Pasirinkite automobilį nuomai:");
            autoparkas.laisvuAutoListas();
            int pas = scanner.nextInt();
            Automobilis auto = autoparkas.getAuto(pas - 1);

            if (auto != null) {
                autoparkas.nuomuotiAuto(auto);
                autoparkas.autoNuomo(auto, username);
                System.out.println("Nuomuotas automobilis: " + auto);
            } else {
                System.out.println("Automobilis nerastas.");
            }
        }
    }

    private static void Grazinti(AutParkas autoparkas) {
        if (autoparkas.arUserNuomuojasi("user")) {
            Automobilis grazintAuto = autoparkas.getUserNuomAuto("user");

            if (grazintAuto != null) {
                autoparkas.grazintiAuto(grazintAuto);
                autoparkas.remNuomAuto(grazintAuto, "user");
                System.out.println("Grąžintas automobilis: " + grazintAuto);
            } else {
                System.out.println("Automobilis nerastas.");
            }
        } else {
            System.out.println("Jūs nesate išsinuomavęs automobilio.");
        }
    }

    private static void Pridet(Scanner scanner, AutParkas autoparkas) {
        System.out.print("Įveskite automobilio markę: ");
        String marke = scanner.next();
        System.out.print("Įveskite automobilio modelis: ");
        String modelis = scanner.next();
        System.out.print("Įveskite automobilio metus: ");
        int metai = scanner.nextInt();

        System.out.print("Įveskite automobilio tipą (E / V): ");
        String autoTipas = scanner.next();

        Automobilis naujasAuto;

        if ("E".equalsIgnoreCase(autoTipas)) {
            naujasAuto = new ElektrinisAutomobilis(marke, modelis, metai);
        } else if ("V".equalsIgnoreCase(autoTipas)) {
            naujasAuto = new VarikliniaiAutomobiliai(marke, modelis, metai);
        } else {
            System.out.println("Neteisingas automobilio tipas. Pridėjimas nutrauktas.");
            return;
        }

        autoparkas.addAuto(naujasAuto);

        System.out.println("Automobilis pridėtas: " + naujasAuto);

    }

    private static void perziuretLaisvas(AutParkas autoparkas) {
        System.out.println("Laisvi automobiliai:");
        autoparkas.laisvuAutoListas();
    }

    private static void perziuretIsnuomuotas(AutParkas autoparkas) {
        System.out.println("Išsinuomoti automobiliai:");
        int i = 1;
        for (Automobilis nuomaAuto : autoparkas.getRentedAutos()) {
            System.out.println(i + ". " + nuomaAuto);
            i++;
        }
    }

    private static void callPapildymas(Scanner scanner, AutParkas autoparkas) {
        System.out.println("Pasirinkite automobilį, kuriam norite papildyti kuro:");
        autoparkas.laisvuAutoListas();
        int pas = scanner.nextInt();
        Automobilis auto = autoparkas.getAuto(pas - 1);

        if (auto != null) {
            autoparkas.callPapildymas(auto);
        } else {
            System.out.println("Automobilis nerastas.");
        }
    }
    private static void callPlovimas(Scanner scanner, AutParkas autoparkas) {
        System.out.println("Pasirinkite automobilį, kuri noreite nuplauti:");
        autoparkas.laisvuAutoListas();
        int pas = scanner.nextInt();
        Automobilis auto = autoparkas.getAuto(pas - 1);

        if (auto != null) {
            autoparkas.callPlovimas(auto);
        } else {
            System.out.println("Automobilis nerastas.");
        }
    }
}
