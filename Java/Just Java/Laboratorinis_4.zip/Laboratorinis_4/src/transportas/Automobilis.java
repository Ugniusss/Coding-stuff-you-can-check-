package transportas;

public class Automobilis extends TransportoPriemone  {
    public Automobilis(String marke, int metai, String modelis) {
        super(marke, metai, modelis);
    }

    @Override
    public String gautiInformacija() {
        return "Automobilis: " + getMarke() + ", " + getModelis() + ", " + getMetai() + " m.";
    }

    @Override
    public String toString() {
        return "Automobilis : " + getMarke() + ", " + getMetai() + " m.";
    }

}

