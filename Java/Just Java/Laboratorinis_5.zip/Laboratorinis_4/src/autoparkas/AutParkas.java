package autoparkas;

import exceptions.MetuIsimtis;
import transportas.AutomobilioAptarnavimas;
import transportas.Automobilis;

import exceptions.MetuIsimtis;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class AutParkas {

    //private List<Automobilis> visiAuto;
    private List<Automobilis> laisviAuto;
    private List<Automobilis> rentedAutos;

    private Map<String, Automobilis> rentedAutosByUsername = new HashMap<>();

    public AutParkas() {
        laisviAuto = new ArrayList<>();
        //visiAuto = new ArrayList<>();
        rentedAutos = new ArrayList<>();
    }


    public void autoNuomo(Automobilis auto, String username) {
        rentedAutosByUsername.put(username, auto);
        laisviAuto.remove(auto);
    }

    public void remNuomAuto(Automobilis auto, String username) {
        rentedAutosByUsername.remove(username);
        rentedAutos.remove(auto);
    }

    public boolean arUserNuomuojasi(String username) {
        return rentedAutosByUsername.containsKey(username);
    }

    public Automobilis getUserNuomAuto(String username) {
        return rentedAutosByUsername.get(username);
    }
    public void addAuto(Automobilis auto) throws MetuIsimtis {
        if (auto.getMetai() < 1900 || auto.getMetai() > 2023) {
            throw new MetuIsimtis(" " + auto.getMetai());
        }
        try {
            Automobilis clonedAuto = auto.clone();
            laisviAuto.add(clonedAuto);
            if (clonedAuto instanceof AutomobilioAptarnavimas aptarnavimas) {
                aptarnavimas.aptarnauti();
            } else {
                System.out.println("Automobilis neturi aptarnavimo funkcionalumo.");
            }

            System.out.println("Automobilis pridėtas: " + clonedAuto);
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            System.out.println("Klonavimas nepavyko. Automobilis nepridėtas.");
        }
    }
/*
    public void addVariklinisAuto(String marke, String modelis, int metai) {
        VarikliniaiAutomobiliai auto = new VarikliniaiAutomobiliai(marke, modelis, metai);
        addAuto(auto);
    }

    public void addElektrinisAuto(String marke, String modelis, int metai) {
        ElektrinisAutomobilis auto = new ElektrinisAutomobilis(marke, modelis, metai);
        addAuto(auto);
    }

 */
    public void nuomuotiAuto(Automobilis auto) {
        if (laisviAuto.contains(auto)) {
            laisviAuto.remove(auto);
        } else {
            System.out.println("Sio automobilio autoparke nera!");
        }
    }

    public void grazintiAuto(Automobilis auto) {
        laisviAuto.add(auto);
    }
    public List<Automobilis> getRentedAutos() {
        return new ArrayList<>(rentedAutosByUsername.values());
    }

    /*
    public List<Automobilis> getVisiAutotos() {
        return rentedAutos;
    }
    */



    public void laisvuAutoListas() {
        int i = 1;
        for (Automobilis auto : laisviAuto) {
            System.out.println(i + ". " + auto);
            i++;
        }
    }
    public Automobilis getAuto(int i) {
        if (i >= 0 && i< laisviAuto.size()) {
            return laisviAuto.get(i);
        } else {
            return null;
        }
    }
    public void callPapildymas(Automobilis auto) {
        if (auto instanceof AutomobilioAptarnavimas aptarnavimas) {
            aptarnavimas.papildymas();
        } else {
            System.out.println("Automobilis neturi aptarnavimo funkcionalumo.");
        }
    }

    public void callPlovimas(Automobilis auto) {
        if (auto instanceof AutomobilioAptarnavimas aptarnavimas) {
            aptarnavimas.plovimas();
        } else {
            System.out.println("Automobilis neturi aptarnavimo funkcionalumo.");
        }
    }
}
