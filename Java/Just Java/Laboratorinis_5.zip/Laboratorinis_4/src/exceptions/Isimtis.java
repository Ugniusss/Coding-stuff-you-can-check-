package exceptions;

public class Isimtis extends Exception {
    public Isimtis(String msg) {
        super(msg);
    }
}