package transportas;

public interface AutomobilioAptarnavimas extends Cloneable {
    void papildymas();
    void plovimas();
    default void aptarnauti() {
        System.out.println("Automobilis yra aptarnaujamas...");
        papildymas();
        plovimas();
    }
    TransportoPriemone clone() throws CloneNotSupportedException;
}
