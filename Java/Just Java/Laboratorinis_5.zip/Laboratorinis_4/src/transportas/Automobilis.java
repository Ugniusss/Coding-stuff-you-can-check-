package transportas;

public class Automobilis extends TransportoPriemone {
   private int ratai;
     public void setRatai (int s){

         this.ratai = s;
     }
     public int getRatai(){
         return this.ratai;
     }
    public Automobilis(String marke, int metai, String modelis) {
        super(marke, metai, modelis);
    }

    @Override
    public String gautiInformacija() {
        return "Automobilis: " + getMarke() + ", " + getModelis() + ", " + getMetai() + " m.";
    }

    @Override
    public String toString() {
        return "Automobilis : " + getMarke() + ", " + getMetai() + " m.";
    }

    @Override
    public Automobilis clone() throws CloneNotSupportedException {
        Automobilis cloned = (Automobilis) super.clone();
        return cloned;
    }
}

