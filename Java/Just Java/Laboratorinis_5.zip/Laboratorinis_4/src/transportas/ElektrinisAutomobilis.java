package transportas;

public class ElektrinisAutomobilis extends Automobilis implements AutomobilioAptarnavimas {
    private static final String kuroTipas = "Elektra";

    public ElektrinisAutomobilis(String marke, String modelis, int metai) {
        super(marke, metai, modelis);
    }

    @Override
    public void papildymas() {
        System.out.println("Kraunama elektros baterija.");
    }
    @Override
    public void plovimas() {
        System.out.println("Elektromobilis nuplautas");
    }

    @Override
    public String gautiInformacija() {
        return "Elektrinis automobilis: " + getMarke() +  ", " + getModelis() + ", " + getMetai() + " m., " + kuroTipas;
    }

    @Override
    public String toString() {
        return "Elektrinis automobilis: " + getMarke() + ", " + getModelis() + ", " + getMetai() + " m., " + kuroTipas;
    }
}
