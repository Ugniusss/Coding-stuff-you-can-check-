package transportas;

public abstract class TransportoPriemone {
    private final String marke;
    private final int metai;
    private final String modelis;


    public TransportoPriemone(String marke, int metai, String modelis) {
        this.marke = marke;
        this.metai = metai;
        this.modelis = modelis;
    }

    public String getMarke() {
        return marke;
    }

    public int getMetai() {
        return metai;
    }

    public String getModelis() {
        return modelis;
    }

    public abstract String gautiInformacija();
    @Override
    public TransportoPriemone clone() throws CloneNotSupportedException {
        TransportoPriemone cloned = (TransportoPriemone) super.clone();
        return cloned;
    }
}
