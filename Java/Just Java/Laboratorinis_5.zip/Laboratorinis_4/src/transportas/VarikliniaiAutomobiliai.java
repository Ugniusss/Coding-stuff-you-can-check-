package transportas;

public class VarikliniaiAutomobiliai extends Automobilis implements AutomobilioAptarnavimas{
    private static final String kuroTipas = "Dyzelis/Benzinas";

    public VarikliniaiAutomobiliai(String marke, String modelis, int metai) {
        super(marke, metai, modelis);
    }


    @Override
    public void papildymas() {
        System.out.println("Bakas pripiltas.");
    }
    @Override
    public void plovimas() {
        System.out.println("Automobilis nuplautas");
    }

    @Override
    public String toString() {
        return "Variklinis automobilis: " + getMarke() + ", " + getModelis() + ", " + getMetai() + " m., " + kuroTipas;
    }
}

