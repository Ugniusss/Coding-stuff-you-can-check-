package exceptions;

public class MetuIsimtis extends Isimtis {
    public MetuIsimtis(String msg){
        super(msg);
    }

    public static void HandleMetuIsimtis(MetuIsimtis e){
        System.out.println("Blogi automobilio metai: " + e.getMessage());
    }
}
