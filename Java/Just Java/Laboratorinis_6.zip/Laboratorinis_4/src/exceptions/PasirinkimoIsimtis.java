package exceptions;

public class PasirinkimoIsimtis extends Isimtis{
    public PasirinkimoIsimtis(String msg){
        super(msg);
    }
    public static void PasirinkimoTikrinimas(String pas) throws PasirinkimoIsimtis {
        if (!pas.matches("[1-6]")) {
            throw new PasirinkimoIsimtis(" " + pas);
        }
    }
    public static void HandlePasirinkimoIsimtis(PasirinkimoIsimtis e){
        System.out.println("Ivestas blogas pasirinkimas: " + e.getMessage());
    }
}
