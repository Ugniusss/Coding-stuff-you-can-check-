package transportas;

public interface AutomobilioAptarnavimas {
    void papildymas();
    void plovimas();
    default void aptarnauti() {
        System.out.println("Automobilis yra aptarnaujamas...");
        papildymas();
        plovimas();
    }
}
