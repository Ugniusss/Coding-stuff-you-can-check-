package transportas;

public class Automobilis extends TransportoPriemone implements Cloneable{
    public Automobilis(String marke, int metai, String modelis) {
        super(marke, metai, modelis);
    }

    @Override
    public String gautiInformacija() {
        return "Automobilis: " + getMarke() + ", " + getModelis() + ", " + getMetai() + " m.";
    }

    @Override
    public String toString() {
        return "Automobilis : " + getMarke() + ", " + getMetai() + " m.";
    }

    @Override
    public Automobilis clone() throws CloneNotSupportedException {
        Automobilis cloned = (Automobilis) super.clone();
        return cloned;
    }
}

